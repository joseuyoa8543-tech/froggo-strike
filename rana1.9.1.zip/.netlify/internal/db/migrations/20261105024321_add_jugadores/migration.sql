CREATE TABLE "jugadores" (
	"id" text PRIMARY KEY,
	"profile" jsonb NOT NULL
);
