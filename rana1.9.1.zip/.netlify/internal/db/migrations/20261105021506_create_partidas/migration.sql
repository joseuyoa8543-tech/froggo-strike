CREATE TABLE "partidas" (
	"id" text PRIMARY KEY,
	"row" jsonb NOT NULL,
	"telemetry" jsonb,
	"score" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
