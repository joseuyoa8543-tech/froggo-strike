/* Dashboard público. Une las partidas guardadas (datos.js) con las nuevas (/api/partidas) sin duplicar. */
(function(){
const POLY={"A":{"p":[[175,450],[634,450],[653,684],[216,684]],"l":[223,487]},"B":{"p":[[634,450],[927,450],[932,684],[653,684]],"l":[679,487]},"C":{"p":[[927,450],[1552,450],[1528,684],[932,684]],"l":[970,487]},"F":{"p":[[1552,450],[1927,450],[1884,684],[1528,684]],"l":[1590,487]},"D":{"p":[[138,243],[1964,243],[1927,450],[175,450]],"l":[189,284]},"E":{"p":[[101,35],[2002,35],[1964,243],[138,243]],"l":[154,79]}},Z='ABCDEF',ZN={A:'Intro',B:'Plataformas',C:'Palanca y rampa',D:'Ascenso',E:'Cima y piedra',F:'Guarida'};
const $=id=>document.getElementById(id),esc=t=>String(t).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const fm=t=>Math.floor(t/60)+':'+String(Math.floor(t%60)).padStart(2,'0');
const AC='#9be564',AM='#f2b134',AQ='#6fcfc0',HT='#ff7a2e';
const P={clock:'<circle cx="12" cy="13" r="8"/><path d="M12 8v5l3 2M9 2.5h6"/>',skull:'<path d="M12 3a7 7 0 0 0-7 7c0 2.3 1 3.7 2.5 4.7V18h9v-3.3C18 13.7 19 12.3 19 10a7 7 0 0 0-7-7zM10 18v3M14 18v3"/><circle cx="9" cy="11" r="1.4"/><circle cx="15" cy="11" r="1.4"/>',jump:'<path d="M12 20V6M6 12l6-6 6 6"/>',trophy:'<path d="M7 4h10v5a5 5 0 0 1-10 0V4zM7 6H4v2a3 3 0 0 0 3 3M17 6h3v2a3 3 0 0 1-3 3M12 14v4M8 21h8"/>',flag:'<path d="M6 21V4M6 5h11l-2.5 3.5L17 12H6"/>',ramp:'<path d="M3 20h18M3 20L19 8v12"/>',beetle:'<ellipse cx="12" cy="14" rx="6" ry="5"/><circle cx="12" cy="7.5" r="2.4"/><path d="M12 9v10M6 12l-3-1M6 16l-3 1M18 12l3-1M18 16l3 1M10.5 5.5L8.5 3M13.5 5.5l2-2.5"/>',spider:'<circle cx="12" cy="14" r="3.5"/><circle cx="12" cy="8.5" r="2"/><path d="M9 12L4 8M9 14l-6 1M9 15.5l-4 4M15 12l5-4M15 14l6 1M15 15.5l4 4"/>',phone:'<rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M11 18h2"/>',pc:'<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',check:'<path d="M5 12.5l5 5 9-11"/>',x:'<path d="M6 6l12 12M18 6L6 18"/>',chat:'<path d="M4 5h16v11H9l-5 4V5z"/>',fire:'<path d="M12 3c1 4 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-5 1-9z"/>',map:'<path d="M9 4L3 6v14l6-2 6 2 6-2V4l-6 2-6-2zM9 4v14M15 6v14"/>',chart:'<path d="M4 20V4M4 20h16M8 16v-5M12 16V8M16 16v-3"/>',frog:'<circle cx="7.5" cy="8" r="3"/><circle cx="16.5" cy="8" r="3"/><path d="M3 15c0-3 4-5 9-5s9 2 9 5-4 6-9 6-9-3-9-6z"/><circle cx="7.5" cy="8" r=".8"/><circle cx="16.5" cy="8" r=".8"/>',shield:'<path d="M12 3l7 3v6c0 4-3 7-7 9-4-2-7-5-7-9V6l7-3zM9 12l2 2 4-4"/>',cal:'<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M8 3v4M16 3v4"/>',redo:'<path d="M20 12a8 8 0 1 1-3-6.2M20 4v4h-4"/>',back:'<path d="M15 5l-7 7 7 7"/>',up:'<path d="M12 3v14M6 9l6-6 6 6M5 21h14"/>',list:'<path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/>'};
const ic=(n,s=20,c='currentColor')=>`<svg class="ic" viewBox="0 0 24 24" width="${s}" height="${s}" fill="none" stroke="${c}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[n]}</svg>`;
let syncError=false;
let ROWS=[],metric='deaths',origin='end',MYID='',PLAYERID='',personal=null,refreshing=false;
const me=()=>(typeof RUN!=='undefined'&&RUN.done&&!RUN.sent)?RUN:personal,nickv=()=>(typeof RUN!=='undefined'&&RUN.nick)||personal?.nick||'';
const f=document.createElement('link');f.rel='stylesheet';f.href='https://fonts.googleapis.com/css2?family=Fredoka:wght@500;600;700&display=swap';document.head.appendChild(f);
const css=document.createElement('style');css.textContent=`
#db{position:fixed;inset:0;z-index:60;overflow:auto;display:none;color:#f1efe3;font-family:system-ui,-apple-system,"Segoe UI",sans-serif;background:linear-gradient(#143a2a 0,#0b2418 340px,#081a10 100%);background-attachment:local}
#db:before{content:"";position:fixed;left:0;right:0;bottom:0;height:34vh;pointer-events:none;opacity:.55;background:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 120' preserveAspectRatio='none'%3E%3Cpath d='M0 120V70l25-50 25 50 20-35 25 45 30-60 28 60 22-40 25 50 28-65 30 70 25-40 22 45 25-55 20 60V120z' fill='%230e3320'/%3E%3C/svg%3E") bottom/100% 100% no-repeat}
#db .ff{position:fixed;width:6px;height:6px;border-radius:50%;background:#f7e98a;box-shadow:0 0 14px 5px #f7e98a88;animation:ffl 9s ease-in-out infinite;pointer-events:none}
@keyframes ffl{0%,100%{transform:translate(0,0);opacity:.2}50%{transform:translate(40px,-60px);opacity:1}}
#db .w{position:relative;max-width:1120px;margin:0 auto;padding:0 18px 70px}
#db header{position:sticky;top:0;z-index:5;margin:0 -18px 22px;padding:12px 22px;background:linear-gradient(#5b3d22,#3f2a17);border-bottom:4px solid #2a1b0d;box-shadow:0 8px 20px #0007;display:flex;flex-wrap:wrap;gap:10px 16px;align-items:center;justify-content:space-between}
#db header:after{content:"";position:absolute;left:0;right:0;bottom:-10px;height:6px;background:repeating-linear-gradient(90deg,#9be564 0 14px,transparent 14px 22px);opacity:.5;border-radius:0 0 6px 6px}
#db h1{margin:0;font:700 25px Fredoka,system-ui;color:#c9f27c;display:flex;gap:10px;align-items:center;letter-spacing:.3px}
#db .sub{font-size:13px;opacity:.8;display:flex;gap:6px;align-items:center;margin-top:2px}
#db h2{margin:0 0 14px;font:600 22px Fredoka,system-ui;display:flex;gap:10px;align-items:center;color:#f1efe3}
#db h2 .ib{display:grid;place-items:center;width:38px;height:38px;border-radius:12px 4px 12px 4px;background:#9be564;color:#10260f;flex:none}
#db h3{margin:0 0 10px;font:600 17px Fredoka,system-ui}
#db .nav{display:flex;gap:6px;flex-wrap:wrap}
#db .nav a,#db .btn{cursor:pointer;display:inline-flex;gap:6px;align-items:center;border:2px solid #7a5a36;border-radius:999px;padding:6px 13px;font-size:13px;font-weight:600;color:#f1efe3;background:#00000030;text-decoration:none;transition:.15s}
#db .nav a:hover,#db .btn:hover{background:#9be56433;border-color:#9be564;transform:translateY(-1px)}
#db .btn.pri{background:#9be564;color:#10260f;border-color:#9be564;font-size:14px;padding:8px 16px}
#db .btn.on{background:#f2b134;color:#241800;border-color:#f2b134}
#db section{margin-top:34px;scroll-margin-top:96px}
#db .c{position:relative;background:linear-gradient(160deg,#1d4a2f dd,#12301f);background:linear-gradient(160deg,#1f4d31,#12301f);border:2px solid #3d7048;border-radius:26px 6px 26px 6px;padding:18px;box-shadow:0 6px 0 #0a1c12,0 14px 24px #0006}
#db .g{display:grid;gap:16px;grid-template-columns:repeat(auto-fit,minmax(260px,1fr))}
#db .g2{display:grid;gap:16px;grid-template-columns:1fr 1fr}
#db .kpi{display:flex;flex-direction:column;gap:2px;overflow:hidden}#db .kpi b{font:700 38px/1.1 Fredoka,system-ui}#db .kpi span{font-size:13px;opacity:.8}
#db .kpi .ki{display:grid;place-items:center;width:40px;height:40px;border-radius:50%;background:#00000030;margin-bottom:6px}
#db .bar{height:12px;border-radius:7px;background:#00000040;overflow:hidden}#db .bar>div{height:100%;border-radius:7px;width:0;transition:width 1s cubic-bezier(.2,.8,.2,1)}
#db .mut{opacity:.72;font-size:13px}#db .q{font-size:14px;line-height:1.5}
#db .lb{max-height:520px;overflow:auto;border-radius:14px;background:#0000002a}
#db .lr{display:grid;grid-template-columns:44px minmax(110px,1.6fr) 46px 70px 70px 74px 96px;gap:8px;align-items:center;padding:9px 12px;font-size:14px;min-width:560px;border-bottom:1px solid #ffffff12;transition:background .15s}
#db .lr:not(.lh):hover{background:#9be56418}
#db .lh{position:sticky;top:0;z-index:2;background:#0d2a1b;font-size:12px;text-transform:uppercase;letter-spacing:.8px;opacity:1;color:#a9c9b0}
#db .lr.me{background:#f2b13430;box-shadow:inset 4px 0 0 #f2b134}
#db .pill{display:inline-flex;gap:4px;align-items:center;border-radius:999px;padding:2px 9px;font-size:12px;font-weight:700}
#db .dots{display:inline-flex;gap:3px}#db .dots i{width:9px;height:9px;border-radius:50%;background:#ffffff26}#db .dots i.o{background:#f2b134}
#db .rv{max-height:520px;overflow:auto;display:flex;flex-direction:column;gap:12px;padding-right:4px}
#db .rc{background:#0000002e;border:1px solid #ffffff18;border-radius:18px 18px 18px 4px;padding:12px 14px}
#db .av{width:38px;height:38px;border-radius:50%;display:grid;place-items:center;font:700 17px Fredoka,system-ui;color:#10260f;flex:none}
#db .rh{display:flex;gap:10px;align-items:center;margin-bottom:8px}
#db .tags{display:flex;gap:6px;flex-wrap:wrap;margin-top:10px}#db .tags span{display:inline-flex;gap:4px;align-items:center;font-size:12px;background:#ffffff14;border-radius:999px;padding:3px 9px}
#db .map{position:relative}#db .map img,#db .map svg{display:block;width:100%;border-radius:18px 4px 18px 4px}#db .map svg{position:absolute;inset:0;height:100%}
#db .hero{display:grid;gap:16px;grid-template-columns:repeat(auto-fit,minmax(220px,1fr))}
#db .row{display:grid;grid-template-columns:26px 1fr auto;gap:10px;align-items:center;padding:6px 4px;font-size:14px}
@media(max-width:820px){#db .g2,#db .mapg{grid-template-columns:1fr!important}}
@media(prefers-reduced-motion:reduce){#db .ff{display:none}#db .bar>div{transition:none}}`;document.head.appendChild(css);
/* ---------- datos ---------- */
// La respuesta remota reemplaza todos los campos, incluso valores vacíos o menores.
function merge(a){return [...new Map(a.map(r=>[r.i,{...r}])).values()]}
function champions(rows){const m=new Map();for(const r of rows.filter(r=>r.c)){const key=r.j||r.i,o=m.get(key);if(!o||r.t<o.t||(r.t===o.t&&r.d<o.d))m.set(key,r)}for(const [key,r] of m){const survey=rows.find(x=>(x.j||x.i)===key&&x.q);if(survey)m.set(key,{...r,q:survey.q})}return [...m.values()].sort((a,b)=>a.t-b.t||a.d-b.d)}
async function hid(s,full=false){try{const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s));return [...new Uint8Array(b)].slice(0,full?32:5).map(x=>x.toString(16).padStart(2,'0')).join('')}catch(e){return 'me'}}
function myRow(){const r=me();if(!r)return null;const q=r.q||{};return{i:MYID,j:PLAYERID,ts:new Date().toISOString().slice(0,16),t:Math.round(r.tt),c:1,d:r.dA+r.dB,da:r.dA,de:r.dB,dv:('ontouchstart' in window)?'m':'p',jt:r.jt,jc:r.jc,jm:r.jm,fa:r.falls,st:r.stomps,ck:r.ck,rp:r.ramp,tz:[...Z].map(z=>Math.round(r.tz[z])),mz:[...Z].map(z=>r.dz[z]),q:q.q_dificultad?[q.q_entendio,q.q_noto_entorno,q.q_diversion,q.q_dificultad]:null,cm:q.q_comentario||'',n:r.nick||'',me:1}}
let lastLive=[];
async function load(){let live=lastLive;syncError=false;try{const c=new AbortController(),t=setTimeout(()=>c.abort(),4000),r=await fetch('/api/partidas',{signal:c.signal});clearTimeout(t);if(r.ok){const j=await r.json();if(j&&Array.isArray(j.rows)){live=j.rows;lastLive=live;}else syncError=true}else syncError=true}catch(e){syncError=true}
 const mine=typeof RUN!=='undefined'&&RUN.done&&!RUN.sent?myRow():null;
 ROWS=merge([...(window.SNAP?window.SNAP.rows:[]),...live,...(mine?[mine]:[])]);
 ROWS.forEach(r=>{r.me=r.i===MYID||r.j===PLAYERID});
 const best=champions(ROWS).find(r=>r.me),own=ROWS.find(r=>r.i===MYID&&r.c)||best;
 personal=own?{nick:own.n,tt:own.t,best:best?.t||own.t,rec:RUN.done?RUN.rec:0,dA:own.da,dB:own.de,jt:own.jt,jc:own.jc,jm:own.jm,falls:own.fa,stomps:own.st,ck:own.ck,ramp:own.rp,tz:Object.fromEntries([...Z].map((z,i)=>[z,own.tz[i]]))}:null;}
const sum=a=>a.reduce((x,y)=>x+y,0),avg=a=>a.length?sum(a)/a.length:0;
function agg(){const R=ROWS,C=R.filter(r=>r.c),E=R.filter(r=>r.q),ts=R.map(r=>r.ts).filter(Boolean).sort(),A={R,C,E,n:R.length,times:C.map(r=>r.t).sort((a,b)=>a-b)};
 A.zones={};Z.split('').forEach((z,k)=>{A.zones[z]={deaths:sum(R.map(r=>r.mz[k])),tavg:avg(C.map(r=>r.tz[k])),abandon:R.filter(r=>!r.c&&(r.tz.map((v,j)=>v>0?j:-1).reduce((a,b)=>Math.max(a,b),0)===k)).length}});
 A.da=sum(R.map(r=>r.da));A.de=sum(R.map(r=>r.de));A.dAvg=avg(R.map(r=>r.d));A.stomps=avg(R.map(r=>r.st));A.falls=avg(R.map(r=>r.fa));
 A.ck=Math.round(avg(R.map(r=>r.ck))*100);A.rp=Math.round(avg(R.map(r=>r.rp))*100);A.jc=Math.round(sum(R.map(r=>r.jc))/Math.max(1,sum(R.map(r=>r.jt)))*100);A.mov=R.filter(r=>r.dv==='m').length;
 A.sv=[0,1,2,3].map(k=>{const o={};E.forEach(r=>o[r.q[k]]=(o[r.q[k]]||0)+1);return o});A.dif=avg(E.map(r=>+r.q[3]||0));
 A.t0=ts[0];A.t1=ts[ts.length-1];A.days={};R.forEach(r=>{if(r.ts){const d=r.ts.slice(0,10);A.days[d]=(A.days[d]||0)+1}});return A}
const dfmt=s=>!s?'sin partidas':new Date(s.slice(0,10)+'T12:00:00').toLocaleDateString('es-MX',{day:'numeric',month:'short',year:'numeric'});
/* ---------- piezas ---------- */
const kp=(i,b,s,col=AC,n)=>`<div class="c kpi"><div class="ki" style="color:${col}">${ic(i,22)}</div><b ${n!=null?`data-n="${n}"`:''}>${b}</b><span>${s}</span></div>`;
const hb=(i,t)=>`<h2><span class="ib">${ic(i,22)}</span>${t}</h2>`;
const bar=(w,col)=>`<div class="bar"><div data-w="${Math.max(2,Math.min(100,w)).toFixed(1)}" style="background:${col}"></div></div>`;
const medal=i=>i<3?`<span style="color:${['#f2b134','#cfd8d3','#d39a6a'][i]}">${ic('trophy',22)}</span>`:`<b style="opacity:.7">${i+1}</b>`;
const dots=n=>`<span class="dots" title="Dificultad ${n}/5">${[1,2,3,4,5].map(i=>`<i class="${i<=n?'o':''}"></i>`).join('')}</span>`;
const nm=r=>r.n?esc(r.n):'<span class="mut">Anónimo</span>';
function lbHTML(A){const all=champions(A.R);
 const head='<div class="lr lh"><span>#</span><span>Jugador</span><span>Disp.</span><span>Tiempo</span><span>Muertes</span><span>Nivel</span><span>Dificultad</span></div>';
 return `<div class="lb">${head}${all.map((r,i)=>`<div class="lr ${r.me?'me':''}"><span>${r.c?medal(i):'<span class="mut">—</span>'}</span><span>${nm(r)}${r.me?' <span class="pill" style="background:#f2b134;color:#241800">tú</span>':''}${r.c&&r.d===0?` <span style="color:${AQ}" title="Sin muertes">${ic('shield',16)}</span>`:''}</span><span title="${r.dv==='m'?'Móvil':'PC'}">${ic(r.dv==='m'?'phone':'pc',18)}</span><b>${fm(r.t)}</b><span>${r.d}</span><span>${r.c?`<span class="pill" style="background:#9be56426;color:${AC}">${ic('check',13)} Sí</span>`:`<span class="pill" style="background:#ff7a2e26;color:${HT}">${ic('x',13)} No</span>`}</span><span>${r.q?dots(+r.q[3]):'<span class="mut">—</span>'}</span></div>`).join('')}</div><div class="mut" style="margin-top:8px">Solo partidas completadas: el mejor tiempo de cada dispositivo. Ordenado por tiempo; a igual tiempo, menos muertes primero. El escudo marca terminar sin morir. La dificultad solo aparece si el jugador respondió el cuestionario.</div>`}
function mapHTML(A){const v=z=>metric==='deaths'?A.zones[z].deaths:metric==='abandon'?A.zones[z].abandon:A.zones[z].tavg,mx=Math.max(...[...Z].map(v),1),top=[...Z].sort((a,b)=>v(b)-v(a)),f1=x=>Math.round(x*10)/10;
 const polys=Z.split('').map(z=>{const p=POLY[z],o=.08+.6*v(z)/mx,hot=top.slice(0,3).includes(z);return `<polygon points="${p.p.map(q=>q.join(',')).join(' ')}" fill="${HT}" fill-opacity="${o.toFixed(2)}" stroke="${hot?AM:'#fff'}" stroke-opacity="${hot?1:.35}" stroke-width="${hot?7:2}"/><text x="${p.l[0]}" y="${p.l[1]}" font-size="62" font-weight="800" fill="#fff" stroke="#10230f" stroke-width="12" paint-order="stroke">${z} · ${f1(v(z))}</text>`}).join('');
 const list=top.map((z,i)=>`<div class="row"><span style="color:${HT}">${i<3?ic('fire',20):''}</span><div><div>${z} · ${ZN[z]}</div>${bar(v(z)/mx*100,HT)}</div><b>${f1(v(z))}</b></div>`).join('');
 const b=(k,i,t)=>`<button class="btn ${metric===k?'on':''}" data-m="${k}">${ic(i,16)} ${t}</button>`;
 return `<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px">${b('deaths','skull','Muertes')}${b('abandon','x','Abandonos')}${b('time','clock','Tiempo por zona (s)')}</div><div class="g2 mapg" style="grid-template-columns:2fr 1fr"><div class="map"><img src="/mapa3d.jpg" alt="Render 3D del nivel"><svg viewBox="0 0 2080 800" aria-label="Zonas del nivel">${polys}</svg></div><div class="c"><div class="mut" style="margin-bottom:8px">${{deaths:'Muertes',abandon:'Abandonos (última zona)',time:'Segundos medios'}[metric]} por zona · más naranja = más difícil</div>${list}</div></div>`}
function hist(A){const t=A.times;if(!t.length)return '';const mn=Math.floor(Math.min(...t)/10)*10,cap=Math.max(mn,Math.min(Math.max(...t),300)),bins=[];for(let s=mn;s<=cap;s+=15)bins.push({s,n:0});for(const x of t)bins[Math.min(bins.length-1,Math.floor((Math.min(x,cap)-mn)/15))].n++;
 const mx=Math.max(...bins.map(b=>b.n)),W=560,H=200,bw=W/bins.length,mt=me()?Math.min(bins.length-1,Math.floor((Math.min(me().tt,cap)-mn)/15)):-1;
 return `<svg viewBox="0 0 ${W} ${H+30}" width="100%" role="img" aria-label="Histograma de tiempos">${bins.map((b,i)=>`<rect x="${i*bw+3}" y="${H-b.n/mx*H}" width="${Math.max(1,bw-6)}" height="${b.n/mx*H}" rx="5" fill="${i===mt?AM:AQ}"/><text x="${i*bw+bw/2}" y="${H+18}" font-size="15" fill="#cfe" text-anchor="middle">${b.s>=60?fm(b.s):b.s+'s'}</text>`).join('')}</svg>`}
function donut(p,col,l1,l2){const R=46,C=2*Math.PI*R;return `<div style="display:flex;gap:14px;align-items:center;margin-bottom:12px"><svg viewBox="0 0 120 120" width="108" height="108"><circle cx="60" cy="60" r="${R}" fill="none" stroke="#00000040" stroke-width="14"/><circle cx="60" cy="60" r="${R}" fill="none" stroke="${col}" stroke-width="14" stroke-dasharray="${C*p/100} ${C}" transform="rotate(-90 60 60)" stroke-linecap="round"/><text x="60" y="67" text-anchor="middle" font-size="25" font-weight="700" fill="#fff">${p}%</text></svg><div><b>${l1}</b><div class="mut">${l2}</div></div></div>`}
function stack(t,o,order,cols){const ks=order.filter(k=>o[k]),T=sum(ks.map(k=>o[k]))||1;return `<div style="margin-bottom:16px"><div class="q" style="margin-bottom:6px">${t}</div><div style="display:flex;border-radius:12px;overflow:hidden;box-shadow:0 3px 0 #0a1c12">${ks.map(k=>{const i=order.indexOf(k),n=o[k];return `<div title="${esc(k)}: ${n}" style="width:${n/T*100}%;background:${cols[i]};color:#0b1710;font-weight:700;font-size:13px;text-align:center;padding:10px 2px;min-width:30px;white-space:nowrap;overflow:hidden">${n/T<.14?n:esc(k)+' · '+n}</div>`}).join('')}</div></div>`}
const colr=s=>['#9be564','#f2b134','#6fcfc0','#ff9f6b','#c9a7ff','#8fd3ff'][[...s].reduce((a,c)=>a+c.charCodeAt(0),0)%6];
function reviews(A){const L=A.R.filter(r=>r.cm).sort((a,b)=>(b.ts||'')<(a.ts||'')?-1:1);return `<div class="rv">${L.map(r=>`<div class="rc"><div class="rh"><div class="av" style="background:${colr(r.n||'Anónimo')}">${esc((r.n||'?')[0].toUpperCase())}</div><div><b>${nm(r)}</b><div class="mut">${r.ts?dfmt(r.ts):''}</div></div></div><div class="q">${esc(r.cm)}</div><div class="tags"><span>${ic(r.dv==='m'?'phone':'pc',13)} ${r.dv==='m'?'Móvil':'PC'}</span>${r.q?`<span>Dificultad ${esc(r.q[3])}/5</span><span>Diversión: ${esc(r.q[2])}</span>`:''}<span>${ic(r.c?'check':'x',13)} ${r.c?'Concluyó':'No concluyó'}</span></div></div>`).join('')||'<div class="mut">Aún no hay comentarios.</div>'}</div>`}
/* ---------- render ---------- */
function render(){
 const A=agg(),r=me(),comp=Math.round(A.C.length/Math.max(1,A.n)*100),med=A.times.length?A.times[Math.floor(A.times.length/2)]:0;
 const days=Object.keys(A.days).sort();
 let h=`<div class="w"><header><div><h1>${ic('frog',30,'#c9f27c')} El pantano en números</h1><div class="sub">${ic('cal',15)} Historial del ${dfmt(A.t0)} al ${dfmt(A.t1)} · ${A.n} partidas</div></div><div class="nav">${[['tu','Tu partida',r],['top','Salón de la fama',1],['mapa','Zonas difíciles',1],['gen','General',1],['opi','Opiniones',1]].filter(x=>x[2]).map(x=>`<a data-t="${x[0]}">${x[1]}</a>`).join('')}</div><button class="btn pri" id="dbx">${origin==='end'?ic('redo',16)+' Jugar de nuevo':ic('back',16)+' Volver'}</button></header>`;
 h+=`<div class="c" role="status" style="margin-bottom:18px">${syncError?'No se pudieron cargar las partidas nuevas. Se muestran los últimos datos disponibles y el historial incluido.':'Historial sincronizado con la base de datos.'} ${RUN.done?(RUN.sent?'Tu partida está guardada.':saveError?'Tu partida aún no se ha guardado. Mantén esta página abierta para reintentar.':'Guardando tu partida…'):''} <button class="btn" id="dbrefresh">Actualizar datos</button>${RUN.done&&!RUN.sent?'<button class="btn" id="dbretry">Reintentar guardado</button>':''}</div>`;
 if(r){const t=Math.round(r.tt),mine=champions(A.R),rank=mine.findIndex(x=>x.me)+1,pct=Math.round((1-(rank-1)/Math.max(1,mine.length))*100),dd=r.dA+r.dB;
  h+=`<section id="tu">${hb('frog','Tu partida'+(nickv()?' · '+esc(nickv()):''))}<div class="hero">${kp('clock',fm(t),r.rec===1?'¡Nuevo récord personal!':'Tu récord: '+fm(r.best||t),AM)}${kp('trophy','#'+rank+' de '+mine.length,'Más rápido que el '+pct+'% de quienes terminaron',AM)}${kp('skull',dd,dd?`muertes (${r.dA} araña · ${r.dB} escarabajo)`:'¡Terminaste sin morir!',HT,dd)}${kp('jump',r.jc+' / '+r.jt,'saltos cargados · '+r.jm+' al máximo',AQ)}</div>
  <div class="g" style="margin-top:16px"><div class="c"><h3>Tu tiempo por zona vs. el promedio</h3>${Z.split('').map((z,k)=>{const a=r.tz[z],b=A.zones[z].tavg,m=Math.max(a,b,20);return `<div style="margin-bottom:10px"><div class="q">${z} · ${ZN[z]}</div>${bar(a/m*100,AM)}<div style="height:4px"></div>${bar(b/m*100,'#a9c2b0')}<div class="mut">tú ${Math.round(a)} s · promedio ${Math.round(b)} s</div></div>`}).join('')}</div>
  <div class="c"><h3>Cómo jugaste</h3><div class="q" style="display:grid;gap:10px">${[['flag',r.ck?'Activaste el checkpoint':'No activaste el checkpoint'],['ramp',r.ramp?'Usaste la rampa':'No usaste la rampa'],['beetle','Escarabajos aplastados: '+r.stomps],['up','Caídas desde lo alto: '+r.falls]].map(x=>`<div style="display:flex;gap:10px;align-items:center;color:#f1efe3"><span style="color:${AC}">${ic(x[0],22)}</span>${x[1]}</div>`).join('')}</div></div></div></section>`}
 h+=`<section id="top">${hb('trophy','Salón de la fama')}<div class="c">${lbHTML(A)}</div></section>
 <section id="mapa">${hb('fire','Las partes más difíciles')}<div id="mapc">${mapHTML(A)}</div></section>
 <section id="gen">${hb('chart','Panorama general')}<div class="hero">${kp('list',A.n,'partidas jugadas',AC,A.n)}${kp('flag',comp+'%','llegó a la puerta ('+A.C.length+')',AC)}${kp('clock',fm(med),'Mediana de tiempo para terminar',AQ)}${kp('skull',A.dAvg.toFixed(1),'muertes por partida',HT)}</div>
 <div class="g" style="margin-top:16px"><div class="c"><h3>¿Cuánto tardan en terminar?</h3>${hist(A)}<div class="mut">Cada barra agrupa 15 s${r?' · en amarillo, tú':''}</div></div>
 <div class="c"><h3>Quiénes juegan y terminan</h3>${donut(comp,AC,'Concluyeron','el resto abandonó')}${donut(Math.round(A.mov/Math.max(1,A.n)*100),AQ,'Juegan en móvil','el resto, en PC')}</div>
 <div class="c"><h3>Qué los derrota</h3>${(()=>{const t=A.da+A.de||1;return `<div class="q" style="display:flex;gap:8px;align-items:center;color:${HT}">${ic('beetle',20)}<span style="color:#f1efe3">Escarabajos <b>${Math.round(A.de/t*100)}%</b></span></div>${bar(A.de/t*100,HT)}<div class="q" style="display:flex;gap:8px;align-items:center;margin-top:12px;color:${AM}">${ic('spider',20)}<span style="color:#f1efe3">Araña <b>${Math.round(A.da/t*100)}%</b></span></div>${bar(A.da/t*100,AM)}`})()}<div class="q" style="margin-top:16px">Saltos cargados: <b>${A.jc}%</b><br>Checkpoint: <b>${A.ck}%</b> · Rampa: <b>${A.rp}%</b><br>Aplastados por partida: <b>${A.stomps.toFixed(1)}</b> · Caídas: <b>${A.falls.toFixed(1)}</b></div></div>
 ${days.length>1?`<div class="c"><h3>Partidas por día</h3>${days.map(d=>`<div class="row" style="grid-template-columns:90px 1fr 34px"><span class="mut">${dfmt(d)}</span>${bar(A.days[d]/Math.max(...Object.values(A.days))*100,AC)}<b>${A.days[d]}</b></div>`).join('')}</div>`:''}</div></section>
 <section id="opi">${hb('chat','Opiniones de los jugadores')}<div class="g2"><div class="c"><h3>Cuestionario <span class="mut">(${A.E.length} personas)</span></h3>${stack('¿Entendió lo que debía hacer?',A.sv[0],['Sí','Más o menos','No'],[AQ,AM,HT])}${stack('¿Notó lo que el entorno sugería?',A.sv[1],['Sí','Algo','No'],[AQ,AM,HT])}${stack('¿Se divirtió?',A.sv[2],['Mucho','Bastante','Poco','Nada'],[AQ,'#3f9c90',AM,HT])}${stack('Dificultad (1 fácil · 5 difícil) — media '+A.dif.toFixed(1),A.sv[3],['1','2','3','4','5'],['#9ee0d3',AQ,'#3f9c90',AM,'#c97b14'])}</div><div class="c"><h3>Comentarios</h3>${reviews(A)}</div></div></section></div>`;
 const el=$('db');el.innerHTML=h;for(let i=0;i<6;i++){const s=document.createElement('span');s.className='ff';s.style.cssText=`left:${8+i*17}%;top:${20+(i*37)%60}%;animation-delay:${i*1.3}s`;el.appendChild(s)}
 requestAnimationFrame(()=>requestAnimationFrame(anim))}
function anim(){const el=$('db');el.querySelectorAll('[data-w]').forEach(b=>b.style.width=b.dataset.w+'%');el.querySelectorAll('[data-n]').forEach(b=>{const n=+b.dataset.n,t0=performance.now();(function s(t){const k=Math.min(1,(t-t0)/800);b.textContent=Math.round(n*k);if(k<1)requestAnimationFrame(s)})(t0)})}
window.openDash=async function(from){origin=from||'end';let el=$('db');if(!el){el=document.createElement('div');el.id='db';document.body.appendChild(el);
 el.addEventListener('click',async e=>{if(e.target.closest('#dbretry')){await send();await refresh();return}if(e.target.closest('#dbrefresh')){await refresh();return}const m=e.target.closest('[data-m]');if(m){metric=m.dataset.m;$('mapc').innerHTML=mapHTML(agg());anim();return}
  const a=e.target.closest('.nav a');if(a){const t=$(a.dataset.t);if(t)el.scrollTo({top:t.offsetTop-80,behavior:'smooth'});return}
  if(e.target.closest('#dbx')){location.assign('/')}})}
 el.style.display='block';el.innerHTML='<div class="w" style="padding-top:90px;text-align:center;font-size:18px">Cargando estadísticas…</div>';
 MYID=typeof RUN!=='undefined'?await hid(RUN.sid):'';PLAYERID=typeof DEVICE!=='undefined'?await hid(DEVICE,true):'';await load();render();el.scrollTop=0};
async function refresh(){const el=$('db');if(refreshing||!el||el.style.display!=='block')return;refreshing=true;try{await load();render()}finally{refreshing=false}}
document.addEventListener('rana-save',refresh);
setInterval(()=>{if(!document.hidden)refresh()},30000);
addEventListener('online',refresh);
addEventListener('focus',refresh);
if(/^\/dashboard\/?$/.test(location.pathname))openDash('start');
})();
